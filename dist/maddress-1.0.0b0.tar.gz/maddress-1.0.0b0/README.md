# Overview 
This package provides developers with handy tools for email address data cleaning