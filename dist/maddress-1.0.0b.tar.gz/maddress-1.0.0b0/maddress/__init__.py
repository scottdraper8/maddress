# Make submodules available
import maddress.domain